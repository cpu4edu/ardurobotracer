EAGLE AutoRouter Statistics:

Job           : C:/Users/khaya/Documents/eagle/ArduinoRobotracer/ArduinoRobotracer.brd

Start at      : 17:04:38 (2019/08/23)
End at        : 17:04:38 (2019/08/23)
Elapsed time  : 00:00:00

Signals       :    36   RoutingGrid: 50 mil  Layers: 2
Connections   :    96   predefined:  95 ( 1 Vias )

Router memory :   53340

Passname          :    Busses     Route Optimize1 Optimize2 Optimize3 Optimize4

Time per pass     :  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00
Number of Ripups  :         0         0         0         0         0         0
max. Level        :         0         0         0         0         0         0
max. Total        :         0         0         0         0         0         0

Routed            :         0         1         1         1         1         1
Vias              :         0         0         0         0         0         0
Resolution        :    99.0 %   100.0 %   100.0 %   100.0 %   100.0 %   100.0 %

Final             : 99.0% finished
